<?php
echo md5(date("Y-m-d H:i:s"));
?>